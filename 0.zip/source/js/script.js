function openPageResidentEvil4() {
      window.location.href = "./source/pages/residentEvil4.html";
    }

function openPageMortalKombatShaolinMonks() {
      window.location.href = "./source/pages/mortalKombatShaolinMonks.html";
    }

function openPageCoraline() {
      window.location.href = "./source/pages/coraline.html";
    }
function openPageBen10AlienForce() {
      window.location.href = "./source/pages/ben10AlienForce.html";
    }

function openPageBatmanLegoTheVideoGame() {
      window.location.href = "./source/pages/batmanLegoTheVideoGame.html";
    }
function openPageCrashOfTheTitans() {
      window.location.href = "./source/pages/crashOfTheTitans.html";
    }

function openPageUp() {
      window.location.href = "./source/pages/up.html";
    }




